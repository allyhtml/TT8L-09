import pygame
import os
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Frame

pygame.mixer.init()
pygame.mixer.music.load('background audio.mp3')
pygame.mixer.music.play(-1)  # Repeat and start playing
pygame.mixer.music.set_volume(2)  # Set volume

pygame.time.delay(5000)

def load_image(image_path):
    try:
        # Convert to absolute path
        abs_path = os.path.abspath(image_path)
        image = PhotoImage(file=abs_path)
        return image
    except Exception as e:
        print(f"Failed to load image at {abs_path}: {e}")
        return None

def show_frame(frame):
    frame.tkraise()

window = Tk()
window.geometry("1474x801")
window.configure(bg="#D1EAF0")
window.title("Quebizz")

window.grid_rowconfigure(0, weight=1)
window.grid_columnconfigure(0, weight=1)

# Create frames
main_frame = Frame(window)
gui1_frame = Frame(window, bg="#F7F1AF")
gui2_frame = Frame(window, bg="#ECD5E3")
gui3_frame = Frame(window, bg="#D0F0C0")

for frame in (main_frame, gui1_frame, gui2_frame, gui3_frame):
    frame.grid(row=0, column=0, sticky='nsew')

# Main frame content
canvas = Canvas(main_frame, bg="#D1EAF0", height=801, width=1474, bd=0, highlightthickness=0, relief="ridge")
canvas.place(x=0, y=0)

button_image_1 = load_image("./build/assets/nqa1/button_1.png")
button_1 = Button(main_frame, image=button_image_1, borderwidth=0, highlightthickness=0, command=lambda: print("button_1 clicked"), relief="flat")
button_1.place(x=687.0, y=701.0, width=153.0, height=61.0)

button_image_2 = load_image("./build/assets/nqa1/button_2.png")
button_2 = Button(main_frame, image=button_image_2, borderwidth=0, highlightthickness=0, command=lambda: show_frame(gui3_frame), relief="flat")
button_2.place(x=541.8, y=181.0, width=416.2, height=514.0)

button_image_3 = load_image("./build/assets/nqa1/button_3.png")
button_3 = Button(main_frame, image=button_image_3, borderwidth=0, highlightthickness=0, command=lambda: show_frame(gui1_frame), relief="flat")
button_3.place(x=84.8, y=179.0, width=416.2, height=522.0)

button_image_4 = load_image("./build/assets/nqa1/button_4.png")
button_4 = Button(main_frame, image=button_image_4, borderwidth=0, highlightthickness=0, command=lambda: show_frame(gui2_frame), relief="flat")
button_4.place(x=1004.9, y=179.0, width=416.1, height=505.0)

canvas.create_text(282.0, 71.0, anchor="nw", text="Choose your selective subject !", fill="#000000", font=("Inter Bold", 64 * -1))

image_image_1 = load_image("./build/assets/nqa1/image_1.png")
canvas.create_image(91.0, 81.0, image=image_image_1)

# GUI 1 content
canvas1 = Canvas(gui1_frame, bg="#F7F1AF", height=801, width=1474, bd=0, highlightthickness=0, relief="ridge")
canvas1.place(x=0, y=0)

button_image_5 = load_image("./build/assets/nqa2/button_1.png")
button_5 = Button(gui1_frame, image=button_image_5, borderwidth=0, highlightthickness=0, command=lambda: print("button_1 clicked"), relief="flat")
button_5.place(x=260.0, y=111.0, width=931.9, height=532.3)

questions_physic = [{"question": "Physics Question 1", "answer": "Option 1"}]
current_question_index = 0  # Initialize index to 0

text_widget_1 = Text(gui1_frame, wrap="word", relief="flat", bd=0, highlightthickness=0, font=("Inter Regular", 16), spacing1=5, spacing2=2)
text_widget_1.pack(expand=True, fill="both")
text_widget_1.insert("end", questions_physic[current_question_index]["question"])
text_widget_1.config(state="disabled")  # Disable editing

def update_question(frame, questions, text_widget):
    text_widget.config(state="normal")  # Enable editing to update content
    text_widget.delete(1.0, "end")  # Clear current content
    question = questions[current_question_index]["question"]
    answer = questions[current_question_index]["answer"]
    text_widget.insert("end", f" {question}\n\n {answer}\n\n")  # Insert question and answer
    text_widget.config(state="disabled")  # Disable editing after update

def next_question(frame, questions, text_widget):
    global current_question_index
    if current_question_index < len(questions) - 1:
        current_question_index += 1
        update_question(frame, questions, text_widget)

def previous_question(frame, questions, text_widget):
    global current_question_index
    current_question_index = (current_question_index - 1) % len(questions)
    update_question(frame, questions, text_widget)

button_image_2 = load_image("./build/assets/nqa3/button_2.png")
button_2 = Button(gui1_frame, image=button_image_2, borderwidth=0, highlightthickness=0, command=lambda: previous_question(gui1_frame, questions_physic, text_widget_1), relief="flat")
button_2.place(x=416.0, y=688.0, width=153.0, height=61.0)

button_image_3 = load_image("./build/assets/nqa3/button_3.png")
button_3 = Button(gui1_frame, image=button_image_3, borderwidth=0, highlightthickness=0, command=lambda: next_question(gui1_frame, questions_physic, text_widget_1), relief="flat")
button_3.place(x=928.0, y=688.0, width=153.0, height=61.0)

button_image_5 = load_image("./build/assets/nqa3/button_5.png")
button_5 = Button(gui1_frame, image=button_image_5, borderwidth=0, highlightthickness=0, command=lambda: show_frame(main_frame), relief="flat")
button_5.place(x=622.0, y=688.0, width=243.0, height=61.0)

# GUI 2 content
canvas2 = Canvas(gui2_frame, bg="#ECD5E3", height=801, width=1474, bd=0, highlightthickness=0, relief="ridge")
canvas2.place(x=0, y=0)

button_image_6 = load_image("./build/assets/nqa3/button_1.png")
button_6 = Button(gui2_frame, image=button_image_6, borderwidth=0, highlightthickness=0, command=lambda: print("button_1 clicked"), relief="flat")
button_6.place(x=260.0, y=111.0, width=931.9, height=532.3)

questions_math = [
    {"question": "If a1=3a_1 = 3a1 =3 and an=2an−1+5a_n = 2a_{n-1} + 5an =2an−1 +5 for n≥2n \geq 2n≥2, what is a3a_3a3 ?", "answer": "21"}
]

text_widget_2 = Text(gui2_frame, wrap="word", relief="flat", bd=0, highlightthickness=0, font=("Inter Regular", 16), spacing1=5, spacing2=2)
text_widget_2.pack(expand=True, fill="both")
text_widget_2.insert("end", questions_math[current_question_index]["question"])
text_widget_2.config(state="disabled")  # Disable editing

button_image_7 = load_image("./build/assets/nqa3/button_2.png")
button_7 = Button(gui2_frame, image=button_image_7, borderwidth=0, highlightthickness=0, command=lambda: previous_question(gui2_frame, questions_math, text_widget_2), relief="flat")
button_7.place(x=416.0, y=688.0, width=153.0, height=61.0)

button_image_8 = load_image("./build/assets/nqa3/button_3.png")
button_8 = Button(gui2_frame, image=button_image_8, borderwidth=0, highlightthickness=0, command=lambda: next_question(gui2_frame, questions_math, text_widget_2), relief="flat")
button_8.place(x=928.0, y=688.0, width=153.0, height=61.0)

button_image_5 = load_image("./build/assets/nqa3/button_5.png")
button_5 = Button(gui2_frame, image=button_image_5, borderwidth=0, highlightthickness=0, command=lambda: show_frame(main_frame), relief="flat")
button_5.place(x=622.0, y=688.0, width=243.0, height=61.0)

# GUI 3 content
canvas3 = Canvas(gui3_frame, bg="#D0F0C0", height=801, width=1474, bd=0, highlightthickness=0, relief="ridge")
canvas3.place(x=0, y=0)

button_image_9 = load_image("./build/assets/nqa4/button_1.png")
button_9 = Button(gui3_frame, image=button_image_9, borderwidth=0, highlightthickness=0, command=lambda: print("button_1 clicked"), relief="flat")
button_9.place(x=260.0, y=111.0, width=931.9, height=532.3)

questions_chemistry = [
    {"question": "What is the boiling point of water?", "answer": "100°C"}
]

text_widget_3 = Text(gui3_frame, wrap="word", relief="flat", bd=0, highlightthickness=0, font=("Inter Regular", 16), spacing1=5, spacing2=2)
text_widget_3.pack(expand=True, fill="both")
text_widget_3.insert("end", questions_chemistry[current_question_index]["question"])
text_widget_3.config(state="disabled")  # Disable editing

button_image_10 = load_image("./build/assets/nqa3/button_2.png")
button_10 = Button(gui3_frame, image=button_image_10, borderwidth=0, highlightthickness=0, command=lambda: previous_question(gui3_frame, questions_chemistry, text_widget_3), relief="flat")
button_10.place(x=416.0, y=688.0, width=153.0, height=61.0)

button_image_11 = load_image("./build/assets/nqa3/button_3.png")
button_11 = Button(gui3_frame, image=button_image_11, borderwidth=0, highlightthickness=0, command=lambda: next_question(gui3_frame, questions_chemistry, text_widget_3), relief="flat")
button_11.place(x=928.0, y=688.0, width=153.0, height=61.0)

button_image_5 = load_image("./build/assets/nqa3/button_5.png")
button_5 = Button(gui3_frame, image=button_image_5, borderwidth=0, highlightthickness=0, command=lambda: show_frame(main_frame), relief="flat")
button_5.place(x=622.0, y=688.0, width=243.0, height=61.0)

show_frame(main_frame)
window.mainloop()


